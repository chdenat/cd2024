<?php
/*******************************************************************************
 * Title:Titre ou texte
 *
 * Slug: noleam/title-or-text
 *
 * Categories: noleam
 ******************************************************************************/

global $post;
?>


<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group">
    <?php
    if (is_home() || is_front_page()) { ?>
        <!-- wp:post-title {"textColor":"white","className":"post-title"} /-->
    <?php } else { ?>
        <!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|40","left":"var:preset|spacing|40","bottom":"var:preset|spacing|40","right":"var:preset|spacing|40"}}},"textColor":"white","className":"post-quote","layout":{"type":"constrained"}} -->
        <div class="wp-block-group post-quote has-white-color has-text-color"
             style="padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)"></div>
        <!-- /wp:group -->
    <?php } ?>
</div>
<!-- /wp:group -->
